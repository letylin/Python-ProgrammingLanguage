# -*- coding: utf-8 -*-
id_num = int(input("請輸入學號末兩碼：")) # 學號
total = int(input("請輸入商品總金額：")) # 商品總金額

base_num = id_num + total # 判斷的基準

remainder = base_num % 11 # 與11的餘數

if remainder == 0:
    print("可以拿到贈品")
else:
    diff = 11 - remainder
    print("不能拿到贈品，還差" + str(diff) + "元")