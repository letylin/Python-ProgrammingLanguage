Weight_kg = int(input("請輸入體重(公斤) = "))
Height_m = float(input("請輸入身高(公分) = ")) / 100
BMI = Weight_kg / (Height_m ** 2)
if BMI < 18.5:
    print("您的BMI = %5.2f %s" %(BMI, "體重過輕"))
elif BMI < 24:
    print("您的BMI = %5.2f %s" %(BMI, "標準體重"))
elif BMI < 27:
    print("您的BMI = %5.2f %s" %(BMI, "體重過重"))
elif BMI < 30:
    print("您的BMI = %5.2f %s" %(BMI, "輕度肥胖"))
elif BMI < 35:
    print("您的BMI = %5.2f %s" %(BMI, "中度肥胖"))
else:
    print("您的BMI = %5.2f %s" %(BMI, "重度肥胖"))