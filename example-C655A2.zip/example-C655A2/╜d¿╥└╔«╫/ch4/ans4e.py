# -*- coding: utf-8 -*-
hours = int(input("請輸入租借的小時數："))
minute = int(input("請輸入租借的分鐘數："))

minute+= hours * 60 # 將小時換成分鐘

# 判斷有幾個時間段需要收費
if minute % 30 == 0:
    cost_set = minute // 30 
else:
    cost_set = minute // 30 + 1

range_1 = 8 * 10 # 四小時以內區間段收費
range_2 = 8 * 20 # 四小時到八小時區間段收費

if hours < 4:
    cost = cost_set * 10
elif hours < 8:
    cost = range_1 + (cost_set - 8) * 20
else:
    cost = range_1 + range_2 + (cost_set - 16) * 40

print("總共需要支付" + str(cost) + "元")
