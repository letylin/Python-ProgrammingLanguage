# -*- coding: utf-8 -*-
"""
Created on Wed Aug  3 16:59:07 2022

@author: user
"""

gender = input("請輸入性別 (男 / 女)：") # 性別

times = int(input("請輸入一分鐘內仰臥起坐的次數：")) # 仰臥起坐次數

if gender == "男":
    if times < 32:
        result = "請加強"
    elif times <= 37:
        result = "中等"
    elif times <= 43:
        result = "銅牌"
    elif times <= 45:
        result = "銀牌"
    else:
        result = "金牌"
        
elif gender == "女":
    if times < 22:
        result = "請加強"
    elif times <= 28:
        result = "中等"
    elif times <= 32:
        result = "銅牌"
    elif times <= 35:
        result = "銀牌"
    else:
        result = "金牌"

print("分級為：" + result)