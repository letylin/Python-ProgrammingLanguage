input_int = int(input("請輸入一個整數值:"))
if input_int % 2 != 0 :
    print("此整數為奇數")
else:
    print("此整數為偶數")