# -*- coding: utf-8 -*-
import random as rd

got_set = set()
times = 0

while len(got_set) < 6:
    got_item = rd.randint(1, 6)    
    times+= 1
    
    got_set.add(got_item)

print("明陽總共轉了" + str(times) + "次集齊所有公仔")