f_list = [1, 1]
for i in range(2, 10):
    new_num = f_list[i-1] + f_list[i-2]
    f_list.append(new_num)

print(f_list)