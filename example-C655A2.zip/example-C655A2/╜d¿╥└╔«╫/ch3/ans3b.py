A = int(input("請輸入整數A:"))
B = int(input("請輸入整數B:"))
result = ( A % B ) == 0
print("整數A是否為整數B的倍數:" + str(result))