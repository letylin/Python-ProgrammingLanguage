pi = 3.14159
inch_5_area = 2.5 * 2.5 * pi #5吋的披薩面積
inch_9_area = 4.5 * 4.5 * pi #9吋的披薩面積

# 比較2個5吋的披薩面積有沒有比1個9吋的披薩面積大
result = (2 * inch_5_area) > inch_9_area
print("5吋圓形披薩面積:" + str(inch_5_area))
print("9吋圓形披薩面積:" + str(inch_9_area))
print("購買2個5吋的披薩比購買1個9吋的披薩划算:" + str(result))