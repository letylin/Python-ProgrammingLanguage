# -*- coding: utf-8 -*-
import random as rd
# 飛鏢命中分數列表
accuracy_list = [1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 4, 4, 5]
max_index = len(accuracy_list) - 1  # accuracy_list 引數最大的值
score = 0                           # 本次遊戲總分
# 射三次飛鏢
for i in range(3):
    hit = rd.randint(0, max_index)  # 以亂數模擬命中的分數
    # 以 hit 配合 accuracy_list，顯示這隻飛鏢命中的得分
    hit_score = accuracy_list[hit]
    score+= hit_score               # 累加分數
print("這次的分數是：" + str(score)) # 輸出本次遊戲總分
