for i in range(1, 6):    #產生 1 到 5 的序列，每圈依序指派給計數器
    print("i = ", i)    #印出 i 的內容值
for i in range(1, 7):
    print("i = ", i / 6)    #印出 i 除以 6 的內容值
for i in range(25, 0, -5):    #產生25到 5 的遞減序列指派給迴圈
    print("i = ", i)