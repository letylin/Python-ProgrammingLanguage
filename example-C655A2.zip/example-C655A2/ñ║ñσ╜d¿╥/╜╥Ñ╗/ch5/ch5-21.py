# -*- coding: utf-8 -*-
total_animal_num = 20 # 全部動物的數量
total_legs_num = 46 # 全部腿的數量

# 因為可能不會整除，但也不會有半隻動物的存在，所以用整數除法取商數
max_chicken = total_legs_num // 2 # 最多的雞數量
max_rabbit = total_legs_num // 4 # 最多的兔子數量

for c in range(0, max_chicken + 1):
    for r in range(0, max_rabbit + 1):
        animal_num = c + r # 當下的動物數量
        legs_num = c * 2 + r * 4 # 當下組合的總腳數
        
        # 若兩者都符合條件，則跳出迴圈，輸出結果
        if legs_num == total_legs_num and animal_num == total_animal_num:
            print("總共有" + str(c) + "隻雞，" + str(r) + "隻兔子")
            break