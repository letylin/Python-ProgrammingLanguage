for i in range(1, 10):   # 外圈
    for j in range(1, 10):   # 內圈
        print("%d*%d=%2d "%(i, j, i * j), end="  ")  
    print( )