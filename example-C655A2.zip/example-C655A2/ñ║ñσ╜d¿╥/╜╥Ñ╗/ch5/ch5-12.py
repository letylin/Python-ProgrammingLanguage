# -*- coding: utf-8 -*-
class_list = ["A", "B", "C"] # 班級代號列表
game_set = set() # 指派一個集合給game_set
# 用雙迴圈兩兩對應
for i in class_list:
    for k in class_list:
        if i != k: # 若兩者為不同班級，則進行分組
            add_list = [i, k] # 將比賽組合放入add_list
            add_list.sort() # 將比賽組合進行排序，如["B", "A"]會變成["A", "B"]
            add_str = add_list[0] + "班對上" + add_list[1] + "班" # 將比賽內容加上字串
            game_set.add(add_str) # 將運算結果放入game_set

game_list = list(game_set) # 將game_set轉換成list，以便排序
game_list.sort() # 將game_list進行排序，以便驗算
print(game_list) # 輸出結果