# -*- coding: utf-8 -*-
shop_name_list = ["M", "K", "B"] # 速食店名稱列表
score_list = [60, 85, 90] # 效用分數列表
price_list = [145, 200, 220] # 價格列表

CP_ratio_list = [] # CP值列表
for i in range(len(shop_name_list)):
    CP_ratio = score_list[i] / price_list[i] # 計算CP值
    CP_ratio_list.append(CP_ratio)

Max_CP = max(CP_ratio_list) # 最高的CP值
Max_CP_index = CP_ratio_list.index(Max_CP) # 根據最高的CP值找出該索引值

# 輸出結果
print("CP值最高的速食店為：速食店" + shop_name_list[ Max_CP_index ])