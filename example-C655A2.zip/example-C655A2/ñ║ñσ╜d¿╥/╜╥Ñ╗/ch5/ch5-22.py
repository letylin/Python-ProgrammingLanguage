# -*- coding: utf-8 -*-
learning_rate = 0.4 # 學習率
unknown_rate = 1 # 從頭開始讀，不懂的比率
target = 0.1 # 將不懂的地方降低到0.1，即10%不懂，可以取得90分
hours_count = 0 # 準備了幾個小時

while unknown_rate >= target:
    unknown_rate*= (1 - learning_rate)
    hours_count+= 1

print("總共需要" + str(hours_count) + "小時")