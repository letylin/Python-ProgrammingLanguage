Temp_Str = list(input("請輸入一字串 = "))
N = len(Temp_Str)
for i in range(N - 1, -1, -1):
    print(Temp_Str[i], end = "")