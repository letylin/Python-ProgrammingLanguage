Age_Drive = int(input("請輸入您的年齡 = "))
if Age_Drive >= 18:
    print("可以報考汽機車駕照")