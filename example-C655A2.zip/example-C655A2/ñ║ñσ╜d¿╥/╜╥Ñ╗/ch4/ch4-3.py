Speed = int(input("請輸入風速等級 = "))
if Speed >=16:
    print("強度颱風")
elif Speed >= 12:
    print("中度颱風")
elif Speed >= 8:
    print("輕度颱風")
else:
    print("沒有到達輕度颱風等級")