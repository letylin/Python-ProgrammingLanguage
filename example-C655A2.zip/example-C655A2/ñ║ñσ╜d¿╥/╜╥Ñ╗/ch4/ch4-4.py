degree = 1100                   # 假設用電度數為1100
range_1 = 120 * 1.63            # 120度以下區間收費
range_2 = (330 - 120) * 2.38    # 121度到330度區間收費
range_3 = (500 - 330) * 3.52    # 331度到500度區間收費
range_4 = (700 - 500) * 4.80    # 501度到700度區間收費
range_5 = (1000 - 700) * 5.66   # 701度到1000度區間收費

if degree <= 120:               # 120度以下區間電費
    cost = degree * 1.63
elif degree <= 330:             # 121度到330度區間電費
    cost = range_1 + (degree - 120) * 2.38
elif degree <= 500:             # 331度到500度區間電費
    cost = range_1 + range_2 + (degree - 330) * 3.52
elif degree <= 700:             # 501度到700度區間電費
    cost = range_1 + range_2 + range_3 + (degree - 500) * 4.80
elif degree <= 1000:            # 701度到1000度區間電費
    cost = range_1 + range_2 + range_3 + range_4 + (degree - 700) * 5.66
else:                           # 1001度以上區間電費
    cost = range_1 + range_2 + range_3 + range_4 + range_5 + (degree - 1000) * 6.99

cost = int( round(cost, 0) )    # 四捨五入到整數位數，並轉換為整數型別
print( "電費為：" + str(cost) + "元" ) 