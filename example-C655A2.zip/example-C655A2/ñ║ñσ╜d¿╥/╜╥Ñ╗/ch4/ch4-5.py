Year = int(input("請輸入西元年份 = "))
if (Year % 400) == 0:                             # 條件1
    print("%d為%s" % (Year, "閏年"))
else:
    if ((Year % 4) == 0) and ((Year % 100) != 0): # 條件2
        print("%d為%s" % (Year, "閏年"))
    else:
        print("%d年為%s" % (Year, "平年"))