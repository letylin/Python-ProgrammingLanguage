x = 2
y = 2
z = 3
if (x + y) <= z:
    print("邊長%d, %d, %d %s" % (x, y, z, "無法形成三角形"))
else:
    if (x ** 2 + y ** 2) == z ** 2:
        print("邊長%d, %d, %d %s" % (x, y, z, "此為直角三角形"))
    if (x ** 2 + y ** 2) < z ** 2:
        print("邊長%d, %d, %d %s" % (x, y, z, "此為銳角三角形"))
    if (x ** 2 + y ** 2) > z ** 2:
        print("邊長%d, %d, %d %s" % (x, y, z, "此為鈍角三角形"))