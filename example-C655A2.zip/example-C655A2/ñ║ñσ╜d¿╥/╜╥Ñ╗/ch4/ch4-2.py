Age_Drive = int(input("請輸入您的年齡 = "))
if Age_Drive >= 18:
    print("符合報考汽機車駕照資格")
else :
    print("不符合報考汽機車資格")