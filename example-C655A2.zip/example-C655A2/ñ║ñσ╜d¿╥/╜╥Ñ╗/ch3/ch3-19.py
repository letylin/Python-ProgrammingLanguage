Num_Y = 100
print(bin(Num_Y))
print(oct(Num_Y))
print(hex(Num_Y))
print(chr(Num_Y))
print(ord('d'))
Str_Rate = "0.0115"
print(type(Str_Rate))
Float_Rate = float(Str_Rate)
print(Float_Rate)
print(type(Float_Rate))
print(Float_Rate * 10000)
print(int(Float_Rate * 10000))