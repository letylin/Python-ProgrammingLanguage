Ironman = ["swimming", 1.5, "run", 10, "bike", 40]
print(Ironman)
print(Ironman[0 : 2])
print(Ironman[10])