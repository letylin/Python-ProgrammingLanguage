Num_X = 5
print(type(Num_X))
callable(Num_X)
callable(int)
isinstance(Num_X, int)
dir(str)
help(print)