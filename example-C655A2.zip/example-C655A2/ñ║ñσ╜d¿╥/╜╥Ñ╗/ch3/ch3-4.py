data = 5
print(data)
data = 50.5
print(data)