import random
num = random.randint(1, 6)
print(num)