Str_Pyadv = "python is Easy to Learn"
print(Str_Pyadv.capitalize( ))
print(Str_Pyadv.upper( ))
print(Str_Pyadv.lower( ))
print(Str_Pyadv.title( ))
print(Str_Pyadv.swapcase( ))