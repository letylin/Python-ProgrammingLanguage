Str_Py= "Python is Good for Beginners"
print(Str_Py.replace("Good", "Best"))
print(Str_Py.find("is"))
print(Str_Py.count("n"))
print(Str_Py.startswith("for", 15, 18))
print(Str_Py.split(" ", 2))
str_1 = "-"
str_2 = ("2023", "11", "08")
print(str_1.join(str_2))
print(Str_Py)
Str_Py = Str_Py.replace("Good", "Best")
print(Str_Py)