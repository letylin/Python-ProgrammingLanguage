Num_A = 10
Num_B = 2
Cond_A = Num_A != Num_B
print(Cond_A)
Cond_B = Num_A == Num_B
print(Cond_B)
print(Cond_A or Cond_B)
print(Cond_A and Cond_B)
print(not Cond_A)
print(not Cond_B)