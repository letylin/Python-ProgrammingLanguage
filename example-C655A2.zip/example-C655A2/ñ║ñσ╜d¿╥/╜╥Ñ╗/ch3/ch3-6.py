Str_X = "Python "
print(Str_X[:])
print(Str_X[2])
print(Str_X[-2])
print(Str_X[-1])
print(Str_X[2 :])
print(Str_X[: : -1])
print(Str_X[0 : : 2])
