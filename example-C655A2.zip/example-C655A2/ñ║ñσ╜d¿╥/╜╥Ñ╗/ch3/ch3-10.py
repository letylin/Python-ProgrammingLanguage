age = 18
reuslt_txt = "%s%d%s" % ("聖嘉今年", age, "歲")
print(reuslt_txt)