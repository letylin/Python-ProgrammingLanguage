Num_C = 5
Num_C += 2
print(Num_C)
Num_C = 5
Num_C -= 2
print(Num_C)
Num_C = 5
Num_C *= 2
print(Num_C)
Num_C = 5
Num_C /= 2
print(Num_C)
Num_C = 5
Num_C //= 2
print(Num_C)
Num_C = 5
Num_C **= 2
print(Num_C)
Num_C = 5
Num_C %= 2
print(Num_C)    