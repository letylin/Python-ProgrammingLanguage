Str_X = "Python "
Str_Y = "is free"
print(Str_X + Str_Y)
print((Str_X + Str_Y) * 3)
print(len(Str_X))