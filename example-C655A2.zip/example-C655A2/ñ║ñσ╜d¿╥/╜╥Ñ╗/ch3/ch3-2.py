Interest = input("請輸入年利率 = ")
print(Interest)
print(type(Interest))