import random as rd
dir(rd)
help(rd.uniform)
num=rd.uniform(0, 1)
print(num)