print(abs(-3))
print(pow(2 , 3))
print(round(4.1204 , 2))
print(divmod(10 , 3))
Sample = [5, 8, 9, 6, 4, 1, 5, 3, 6, 2]
print(max(Sample))
print(min(Sample))
print(sum(Sample))
print(len(Sample))