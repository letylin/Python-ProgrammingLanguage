Num_A = 10
Num_B = 2
print(Num_A > Num_B)
print(Num_A <= Num_B)
print(Num_A != Num_B)
print(Num_A == Num_B)