# -*- coding: utf-8 -*-
rank_list = list(range(1, 101))

# 分班結果
class_dict = {
    "A" : [],
    "B" : [],
    "C" : [],
    "D" : [],
    "E" : []
    }

class_ordinary = ["A", "B", "C", "D", "E"] # 分班順序
class_num = len(class_ordinary) # 班級數
index = 0 # 引數
flag = True # 引數加減指標

for i in rank_list:
    class_name = class_ordinary[index]
    class_dict[class_name].append(i)
    
    
    if flag: # 引數加減指標為真
        index+= 1 # 引數增加
    else: # 引數加減指標為偽
        index-= 1 # 引數減少
    
    # 若引數超過班級數-1，則轉換引數加減指標
    if index > class_num-1:
        index-= 1 # 控制引數保留在班級數-1
        flag = False
    # 若引數小於0，則轉換引數加減指標
    elif index < 0:
        index+= 1 # 控制引數保留在0
        flag = True
    
print(class_dict)
