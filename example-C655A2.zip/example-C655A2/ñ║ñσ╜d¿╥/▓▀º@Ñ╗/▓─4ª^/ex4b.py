# -*- coding: utf-8 -*-
money = eval(input("請輸入須找零的金額："))	#輸入要找的錢

change_type_list = [ 500, 100, 50, 10, 5, 1 ] #定義各種幣值的list
#走訪各種幣值
for c in change_type_list:
	change_num = money // c		#將須找零錢整數除法(取商數)，得到該幣值須找的數量
	print( "找了",change_num, "張(枚)", c ,"元" )	#輸出須找的數量
	money-= c * change_num		#減掉已找的零錢

