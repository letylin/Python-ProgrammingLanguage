# -*- coding: utf-8 -*-
meal_type = [ "燉飯", "義大利麵" ]
sauce_type = [ "紅醬","白醬", "青醬" ]
main_dish = [ "雞肉", "牛肉", "豬肉", "培根", "蛤蜊", "牛肉丸(紅醬限定)" ]
additional = [ "不加點", "唐揚雞", "薯條" ]

select_meal_type = int( input( "請輸入餐點類型，0 = 燉飯, 1 = 義大利麵：" ))
select_sauce_type = int( input( "請選擇醬料，紅醬 = 0, 白醬 = 1, 青醬 = 2：" ))

if select_sauce_type != 0:
    main_dish_txt = "請選擇主菜，雞肉 = 0, 牛肉 = 1, 豬肉 = 2, 培根 = 3, 蛤蜊 = 4,："
else:
    main_dish_txt = "請選擇主菜，雞肉 = 0, 牛肉 = 1, 豬肉 = 2, 培根 = 3, 蛤蜊 = 4, 牛肉丸(紅醬限定) = 5："
select_main_dish = int( input( main_dish_txt ))

select_additional = int( input("請選擇加點，不加點 = 0, 唐揚雞 = 1,薯條 = 2："))

result_txt = sauce_type[ select_sauce_type ] + \
            main_dish[ select_main_dish ] + \
            meal_type[select_meal_type]

if select_additional != 0 :
    result_txt+= "，加點%s" % ( additional[ select_additional ] )

print( result_txt )

