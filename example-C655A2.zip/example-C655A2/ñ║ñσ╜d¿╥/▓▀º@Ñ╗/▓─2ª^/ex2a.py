# -*- coding: utf-8 -*-
id_num = input("請輸入你的身分證字號：") #輸入身分證

#轉換字母
code = {
	"A" : "10",
	"B" : "11",
	"C" : "12",
	"D" : "13",
	"E" : "14",
	"F" : "15",
	"G" : "16",
	"H" : "17",
	"I" : "34",
	"J" : "18",
	"K" : "19",
	"L" : "20",
	"M" : "21",
	"N" : "22",
	"O" : "35",
	"P" : "23",
	"Q" : "24",
	"R" : "25",
	"S" : "26",
	"T" : "27",
	"U" : "28",
	"V" : "29",
	"w" : "32",
	"X" : "30",
	"Y" : "31",
	"Z" : "33!",
	}

#將數字乘以權重加總
first_letter = id_num[0]
trans_num = code[first_letter]
total = int(trans_num[0]) * 1 + int(trans_num[1]) * 9
total+= int(id_num[1]) * 8
total+= int(id_num[2]) * 7
total+= int(id_num[3]) * 6
total+= int(id_num[4]) * 5
total+= int(id_num[5]) * 4
total+= int(id_num[6]) * 3
total+= int(id_num[7]) * 2
total+= int(id_num[8]) * 1
total+= int(id_num[9]) * 1

flag = total % 10 == 0 # 判斷餘數是否等於0

#判斷是否為正確的身分證
print( "是否為正確的身分證字號%s"%( flag ))