List_Week = ["Sun.", "Mon.", "Tue.", "Wed.", "Thu.", "Fri.", "Sat."]
Tuple_FromList = tuple(List_Week)
print(Tuple_FromList)
List_FromTuple = list(Tuple_FromList)
print(List_FromTuple)
Set_FromList = set(List_Week)
print(Set_FromList)
Enumerate_Data = enumerate(List_Week)
print(dict(Enumerate_Data))