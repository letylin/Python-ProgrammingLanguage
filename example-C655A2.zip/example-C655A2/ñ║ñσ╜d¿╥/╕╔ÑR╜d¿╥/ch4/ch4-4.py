Old_Rate = int(input("請輸入舊匯率 = "))
New_Rate = int(input("請輸入新匯率 = "))
Change = ((Old_Rate - New_Rate) / New_Rate) * 100
print(Change)
if Change > 0 :
    Result = "升值"
else :
    Result = "貶值"
print(" 貨幣升貶值幅度 = % 4.2f%s 表示 %s" % (Change, "%", Result))